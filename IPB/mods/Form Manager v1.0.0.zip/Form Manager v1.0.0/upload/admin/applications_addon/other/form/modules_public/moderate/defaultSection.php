<?php

$DEFAULT_SECTION = 'moderate';

?>