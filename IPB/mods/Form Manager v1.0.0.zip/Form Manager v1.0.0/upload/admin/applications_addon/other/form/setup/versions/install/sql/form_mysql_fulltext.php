<?php
$INDEX[] = "ALTER TABLE form_logs ADD FULLTEXT (message);";
?>