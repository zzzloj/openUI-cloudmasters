<?php

$DEFAULT_SECTION = 'index';

?>