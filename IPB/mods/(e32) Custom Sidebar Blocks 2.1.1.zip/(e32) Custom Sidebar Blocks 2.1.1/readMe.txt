#(e32) Custom Sidebar Blocks
#Created by emoney @ http://emoneyCodes.com

This is the simple text version of the Read Me.  If you are having problems opening the actual Read Me please post in your nearest Custom Sidebar Blocks support topic.

Upload:

Upload the contents of the upload folder to your IPB 3.3 root directory.  

Install:

Log in to your IP.Board Admin CP and visit the System tab -> Manage Applications & Modules -> Browse down to (e32) Custom Sidebar Blocks.  Click the Install link and follow the steps.

Upgrade:

Log in to your IP.Board Admin CP and visit the System tab -> Manage Applications & Modules -> Browse down to (e32) Custom Sidebar Blocks.  Click the green upgrade link and follow the steps.

*****
If you don't see the INSTALL link on the Custom Sidebar Blocks row after uploading the files and going to the Manage Applications page, that means something went wrong with the upload.
Double check to make sure you are uploading the proper folders.  You want to upload the contents of the "upload" folder, not the "upload" folder itself.
Here is an FAQ for it, if you are having trouble, please post there: http://emoneycodes.com/forums/topic/291-after-uploading-files-no-installupgrade-button-for-app/
******

Re-import the hook:

If you are upgrading from an earlier version, you may need to re-import the hook. To do so, log in to your IP.Board Admin CP and visit the System tab -> Manage Hooks -> Browse down to Install a New Hook.  Browse for the ibEconomy/xml/hooks/customSidebarBlocksHook.xml file and install.

Setup:

To use the application just scroll down the app dropdown in ACP to (e32) Custom Sidebar Blocks.  Make sure in Manage Settings you enable the app, and make sure you add a block (or more) and enable it. 

Reording Blocks:

There are 3 different places to reorder the blocks:
	1) To change the position of all Custom Sidebar Blocks in relation to the default sidebar blocks, go to ACP->Manage Hooks and drag/drop the Custom Sidebar Blocks hook to the spot you desire.
	2) To change the position WITHIN the Custom Sidebar Blocks, go to ACP->Other Apps->Custom Sidebar Blocks->Custom Blocks and drag/drop the rows.
	3) For the Portal, you can't change the position as surgically as you can on the index. But you do at least have the setting located in ACP->Other Apps->Custom Sidebar Blocks->Manage Settings which you can use to change the overall position.
