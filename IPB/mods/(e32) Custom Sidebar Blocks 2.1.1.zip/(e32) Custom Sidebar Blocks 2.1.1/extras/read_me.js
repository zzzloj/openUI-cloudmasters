function show_hide(divid)
{
	var mydivs = new Array();
	mydivs[0] = "pre_install";
	mydivs[1] = "install";
	mydivs[2] = "setup";

	for (i=0;i<mydivs.length;i++)
	{
		if ( mydivs[i] == divid )
		{
			document.getElementById(mydivs[i]).style.display='block';
			document.getElementById(mydivs[i]+'_tab').className='left active';
		}
		else
		{
			document.getElementById(mydivs[i]).style.display='none';
			document.getElementById(mydivs[i]+'_tab').className='left ';
		}
	}
}