<?php

// Changes to new app title
$SQL[] = "UPDATE core_applications SET app_title='(e32) Custom Sidebar Blocks' WHERE app_title LIKE '%Custom Sidebar Blocks%';";