<?php

$DEFAULT_SECTION = 'core';

?>